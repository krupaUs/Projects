<?php

/**
 * Created by PhpStorm.
 * User: Krupa
 * Date: 9/10/17
 * Time: 8:26 PM
 */
class User
{
    var $id;
    var $email;
    var $password;
    var $rank;
}