var checkin_click_function;
$(document).ready(function(){
    $( "#open_search" ).click(function() {
        console.log("OPEN SEARCH");
        $("#search_tab_content").removeClass('hidden');
        $("#search_tab_content").addClass('visible');
        

        $("#check_out_tab_content").addClass('hidden');
        $("#create_borrower_tab_content").addClass('hidden');
        $("#checkin_tab_content").addClass('hidden');
        $("#fine_tab_content").addClass('hidden');
        $("#pay_fine_tab_content").addClass('hidden');

        
        $("#check_out_tab_content").removeClass('visible');
        $("#create_borrower_tab_content").removeClass('visible');
        $("#checkin_tab_content").removeClass('visible');
        $("#fine_tab_content").removeClass('visible');
        $("#pay_fine_tab_content").removeClass('visible');


    });
    
    $("#check_out").click(
        function() {
            $("#check_out_tab_content").removeClass('hidden');
            $("#check_out_tab_content").addClass('visible');


            $("#search_tab_content").addClass('hidden');
            $("#create_borrower_tab_content").addClass('hidden');
            $("#checkin_tab_content").addClass('hidden');
            $("#fine_tab_content").addClass('hidden');
            $("#pay_fine_tab_content").addClass('hidden');



            $("#search_tab_content").removeClass('visible');
            $("#create_borrower_tab_content").removeClass('visible');
            $("#checkin_tab_content").removeClass('visible');
            $("#fine_tab_content").removeClass('visible');
            $("#pay_fine_tab_content").removeClass('visible');


        }
    );
    
    $( "#create_borrower" ).click(function() {
        console.log("OPEN create_borrower");
        $("#create_borrower_tab_content").removeClass('hidden');
        $("#create_borrower_tab_content").addClass('visible');
        

        $("#check_out_tab_content").addClass('hidden');
        $("#search_tab_content").addClass('hidden');
        $("#checkin_tab_content").addClass('hidden');
        $("#fine_tab_content").addClass('hidden');
        $("#pay_fine_tab_content").addClass('hidden');


        $("#check_out_tab_content").removeClass('visible');
        $("#search_tab_content").removeClass('visible');
        $("#checkin_tab_content").removeClass('visible');
        $("#fine_tab_content").removeClass('visible');
        $("#pay_fine_tab_content").removeClass('visible');


    });
    
    
    $( "#open_check_in" ).click(function() {
        console.log("OPEN open_check_in");
        $("#checkin_tab_content").removeClass('hidden');
        $("#checkin_tab_content").addClass('visible');
        
        $("#check_out_tab_content").addClass('hidden');
        $("#create_borrower_tab_content").addClass('hidden');
        $("#search_tab_content").addClass('hidden');
        $("#fine_tab_content").addClass('hidden');
        $("#pay_fine_tab_content").addClass('visible');


        
        $("#check_out_tab_content").removeClass('visible');
        $("#create_borrower_tab_content").removeClass('visible');
        $("#search_tab_content").removeClass('visible');
        $("#fine_tab_content").removeClass('visible');
        $("#pay_fine_tab_content").removeClass('visible');


    });
    
    $("#open_fine").click(function(){
        
        console.log("Fine");
        $("#fine_tab_content").removeClass('hidden');
        $("#fine_tab_content").addClass('visible');
        
        
        $("#check_out_tab_content").addClass('hidden');
        $("#search_tab_content").addClass('hidden');
        $("#checkin_tab_content").addClass('hidden');
        $("#create_borrower_tab_content").addClass('hidden');
        $("#pay_fine_tab_content").addClass('hidden');

        
        $("#check_out_tab_content").removeClass('visible');
        $("#search_tab_content").removeClass('visible');
        $("#checkin_tab_content").removeClass('visible');
        $("#create_borrower_tab_content").removeClass('visible'); 
        $("#pay_fine_tab_content").removeClass('visible');

        
        ////////
        
        console.log("Now calling ajax function");
        $.ajax({
            type: "POST",
            url: "http://localhost:8888/marchu/db_prjct/db_try.php",
            data: { show_fines: "ALL_FINE" },
            success:function(result){
//                if(result.message.length > 0) {
                console.log("Success for fines");
                    //console.log(result.message);
                    
                    var json_parsed_results = (result.message);
                    var html = '<table>';
                
                    html += '<tr>' 
                            + '<th>LOAN ID</th>' 
                            + '<th>CARD ID</th>'
                            + '<th>DATE IN</th>'
                            + '<th>DATE OUT</th>'
                            + '<th>NO OF DAYS</th>'
                            + '<th>TOTAL FINE AMOUNT</th>'
                            + '</tr>';
                
                    for(var i=0; i<json_parsed_results.length; i++) {
                           
                        var res1 = json_parsed_results[i];
                        var field1 = res1["LOAN_ID"];
                        var field2 = res1["CARD_ID"];
                        var field3 = res1["DATE_IN"];
                        var field4 = res1["DATE_OUT"];
                        var field5 = res1["NO_OF_DAYS"];
                        var field6 = res1["TOTAL_FINE_AMOUNT"];
                                                
                        html += '<tr>' 
                            + '<td>'+field1+'</td>' 
                            + '<td>'+field2+'</td>' 
                            + '<td>'+field3+'</td>' 
                            + '<td>'+field4+'</td>'
                            + '<td>'+field5+'</td>'
                            + '<td>'+field6+'</td>'
                            + '</tr>';
                        
                    }
                
                    html += '</table>';
                    $("#fine_results_div").html(html);
                console.log("ALL FINE AJAX call completed");
//                }
                
            }
        });
        
        ////////
        
        
    }); //// OPEN_FINE tab click ends
    
    $('#pay_fine').click(function() {
        
        
        console.log("pay_fine_tab");
        $("#pay_fine_tab_content").removeClass('hidden');
        $("#pay_fine_tab_content").addClass('visible');
        
        $("#check_out_tab_content").addClass('hidden');
        $("#create_borrower_tab_content").addClass('hidden');
        $("#search_tab_content").addClass('hidden');
        $("#fine_tab_content").addClass('hidden');
        $("#checkin_tab_content").addClass('hidden');
        
        $("#check_out_tab_content").removeClass('visible');
        $("#create_borrower_tab_content").removeClass('visible');
        $("#search_tab_content").removeClass('visible');
        $("#fine_tab_content").removeClass('visible');
        $("#checkin_tab_content").removeClass('visible');

    });
    
    $('#search_content_btn').click(function() {

        console.log("Now making AJAX call");
        $.ajax({
            type: "POST",
            url: "db_try.php",
            data: { search: $("#search_content_txt").val() },
            success:function(result){
                if(result.message.length > 0) {
                    var json_parsed_results = JSON.parse(result.message);
                    var html = '<table>';
                    html += '<tr><th>ISBN</th><th>TITLE</th><th>NAME</th><th>BOOK AVAILABILITY</th></tr>';
                    for(var i=0; i<json_parsed_results.length; i++) {
                        var res1 = JSON.parse(json_parsed_results[i]);
                        if(res1["ISBN"] && res1["TITLE"] && res1["NAME"]) {
                            var isbn = res1["ISBN"];
                            var title = res1["TITLE"];
                            var name = res1["NAME"]; 
                            var book_avail = res1["BOOK_AVAILABILITY"];
                            var avail = "Yes";
                            if (book_avail == 0) {
                                avail = "No";
                            }
                            html += '<tr><td>' + isbn + '</td>'
                                    + '<td>' + title + '</td>'
                                    + '<td>' + name + '</td>'
                                    + '<td>' + avail + '</td>'
                                    + '</tr>';
                        }
                        
                    }
                    html += '</table>';
                    console.log(html);
                    $('#search_results_list').html(html);
                }
                
            }
        });
    });     
    
    $("#book_check_out_btn").click(
        function() {
           $.ajax({
            type: "POST",
            url: "db_try.php",
            data: {
                    borrower_id: $("#borrower_id_txt").val(),
                    isbn: $("#book_isbn_txt").val()
                },
            success:function(result){
//                console.log("Book Check out " + result.message["error"]);
                if(result.message) {
                    var html = "";
                    var json_parsed_results = result.message;
                    console.log(result.message);
                    if (json_parsed_results["loan_id"] != null) {
                        html = "<h4> Book check out is successful, your loan id is " + json_parsed_results["loan_id"] + ". </h4>";
                    } else if(json_parsed_results["error"] != null) {
                        console.log("Cant check out book because " + json_parsed_results["error"]);    
                        html = "<h4> Cant check out book because " + json_parsed_results["error"]+ ". </h4>";
                    }
                    $('#checkout_results').html(html);
                }       
            }
        }); 
        }
    );
    
    
    //
    $("#create_borrower_btn").click(
        function() {
            console.log("Creating borrower");
            $.ajax(
                {
                    type: "POST",
                    url: "db_try.php",
                    data: {
                        borrower_name: $("#borrower_name_txt").val(),
                        ssn: $("#ssn_txt").val(),
                        address: $("#address_txt").val(),
                        phone: $("#phone_txt").val(),
                    },
                    success:function(result){
                        if(result.message) {
                            console.log(result.message);
                            var html = "";
                            var json_parsed_results = result.message;
                            console.log(result.message);
                            if (json_parsed_results["borrower_id"] != null) {
                                html = "<h4> Borrower creation is successful, your borrower id is " + json_parsed_results["borrower_id"] + ". </h4>";
                            } else if(json_parsed_results["error"] != null) {
                                console.log("Cant check out book because " + json_parsed_results["error"]);    
                                html = "<h4> " + json_parsed_results["error"]+ ". </h4>";
                            }
                            $('#borrower_create_results').html(html);
                            
                        }                
                    }
                }
            );
        }
    );
    // check in
    $("#book_check_in_btn").click(
        function() {
            console.log("Check in the book");
            $.ajax(
                {
                    type: "POST",
                    url: "db_try.php",
                    data: {
                        checkin_search_text: $("#checkin_search_text").val()
                    },
                    success:function(result){
                        if(result.message) {
//                            alert(JSON.parse(result.message));
                            var json_parsed_results = (result.message);
                            //alert(json_parsed_results);
                            var html = '<table>';
                            html += '<tr><th>BOOK ID</th><th>CARD NUMBER</th><th>BORROWER NAME</th><th>CHECK IN LINK</th></tr>';
                            for(var i=0; i<json_parsed_results.length; i++) {
                                var res1 = (json_parsed_results[i]);
                                if(res1["BOOK_ID"] && res1["CARD_NUMBER"] && res1["BORROWER_NAME"]) {
                                    var isbn = res1["BOOK_ID"];
                                    var card_num = res1["CARD_NUMBER"];
                                    var borrower_name = res1["BORROWER_NAME"]; 
                                    
                                    html += '<tr><td>' + isbn + '</td>'
                                            + '<td>' + card_num + '</td>'
                                            + '<td>' + borrower_name + '</td>'
                                            + '<td><input type=\"button\" onclick=checkin_click_function(\''+isbn.toString()+'\',\''+card_num+'\') text=\"check in\"></td>'
                                            + '</tr>';
                                }

                            }
                            html += '</table>';
                            $('#check_in_results_div').html(html);
                            
                        }                
                    }
                }
            );
        }
    );
    
    checkin_click_function = function(isbn, checkin_book_card_id) {
        //alert("HANDLE CHECKIN " + isbn);
        $.ajax(
            {
                type: "POST",
                url: "db_try.php",
                data: "checkin_book_isbn=" + isbn + "&checkin_book_card_id=" + checkin_book_card_id,
                success:function(result){
                    if(result.message) {
                        var html = "<h4>" + result.message + "</h4>";
                        $('#check_in_results_div').html(html);
                    }                
                }
            }
        );
    }
    
    /////////// PAY FINE AJAX CALL STARTS
    $("#pay_fine_btn").click(function(){
        console.log("PAY FINE for the book");
            $.ajax({
                type: "POST",
                    url: "db_try.php",
                    data: {
                        pay_fine_loan_id: $("#pay_fine_loan_id_text").val()
                    },
                    success:function(result) {
                        if(result.message) {
                            var html = "<h4>" + result.message + "</h4>";
                            $('#pay_fine_results_div').html(html);
                        }  
                    }
            });
    });
    /////////// PAY FINE AJAX CALL ENDS
    
});







