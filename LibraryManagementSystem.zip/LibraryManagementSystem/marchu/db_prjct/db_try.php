<?php

//header('Content-Type: application/json');
/**
Helper method for sending the json response
*/
function json_response($message = null, $code = 200)
{
    // clear the old headers
    header_remove();
    // set the actual code
    http_response_code($code);
    // set the header to make sure cache is forced
    header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
    // treat this as json
    header('Content-Type: application/json');
    $status = array(
        200 => '200 OK',
        400 => '400 Bad Request',
        422 => 'Unprocessable Entity',
        500 => '500 Internal Server Error'
        );
    // ok, validation error, or failure
    header('Status: '.$status[$code]);
    // return the encoded json
    return json_encode(array(
        'status' => $code < 300, // success or not?
        'message' => $message
        ));
}

/**
returns the database connection
*/
function connect_to_database($username = "root", $password = "root", $dbname, $port="3306") {
    $conn = mysqli_connect("localhost", $username, $password, $dbname, $port);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        return null;
    }
    return $conn;
}


/**
 returns the search results
*/
function execute_query($conn, $db_name, $search_query) {
    if (mysqli_select_db($conn, $db_name)) {
        if(strlen($search_query) > 0) {
//            return mysqli_query($conn, $search_query);
            $results = mysqli_query($conn, $search_query);
            $search_results = array();
            while($row = mysqli_fetch_assoc($results)) {
                $search_results[] = json_encode($row);
                //print_r($temp_array);
            }
            return json_encode($search_results);
        } else {
            echo json_response("empty search query");
        }
    } else {
        echo json_response("Error selecting db");
    }
}

function check_book_availability($conn, $db_name, $isbn) {
    if (mysqli_select_db($conn, $db_name)) {
        if(strlen($isbn) > 0) {
            $search_query = "SELECT BOOK_AVAILABILITY FROM `searchbook` WHERE isbn = '" . $isbn . "';";
            $results = mysqli_query($conn, $search_query);
            $search_results = array();
            $rows = mysqli_fetch_row($results);
            return $rows[0]["BOOK_AVAILABILITY"];
        } else {
            echo json_response("empty search query");
        }
    } else {
        echo json_response("Error selecting db");
    }
}

function get_number_of_borrowed_books($conn, $db_name, $borrower_id) {
    if (mysqli_select_db($conn, $db_name)) {
        if(strlen($borrower_id) > 0) {
            $search_query = "select count(bl.loan_id) as COUNT from book_loans bl where bl.date_in is  null AND bl.card_id='" . $borrower_id . "';";
            //echo $search_query;
            $results = mysqli_query($conn, $search_query);
            $search_results = array();
            $rows = mysqli_fetch_row($results);
            //echo $rows[0];
            return $rows[0]["COUNT"];
        } else {
            echo json_response("empty search query");
        }
    } else {
        echo json_response("Error selecting db");
    }
}

function check_out_book($conn, $db_name, $borrower_id, $isbn) {
    if (mysqli_select_db($conn, $db_name)) {
        if(strlen($borrower_id) > 0 && strlen($isbn) > 0) {
            $insert_book_loan = "insert into book_loans(`card_id`,`date_out`,`due_date`,`isbn`) values(".$borrower_id.",now(), DATE_ADD(NOW(), INTERVAL 14 DAY), '".$isbn."');";   
            //echo "<br>".$insert_book_loan;
            if (mysqli_query($conn, $insert_book_loan)) {
                
                $loan_id = mysqli_insert_id($conn);
                $temp_array=array();
                $temp_array["loan_id"] = $loan_id;
                
                $update_search_book = "update searchbook set BOOK_AVAILABILITY=0 where ISBN='" . $isbn . "';";
                mysqli_query($conn, $update_search_book);  
                echo json_response($temp_array);
            } else {
                echo json_response("Error: " . $sql . "<br>" . mysqli_error($conn));
            }
        } else {
            echo json_response("empty search query");
        }
    } else {
        echo json_response("Error selecting db");
    }
}

// main code entry point
$search_term = "";

$borrower_id = "";
$isbn = "";

$borrower_name = "";
$ssn = "";
$phone = "";
$address = "";

$checkin_search_text = "";

$checkin_book_isbn = "";

// for searching all fines
$search_for_all_fines = "";

$pay_fine_loan_id = "";


if($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST["search"]) && !empty($_POST["search"])) {
        $search_term = $_POST["search"];
    } else if ( 
            isset($_POST["borrower_id"]) && !empty($_POST["borrower_id"]) 
            && 
            isset($_POST["isbn"]) && !empty($_POST["isbn"])   
    ) {
        $borrower_id = $_POST["borrower_id"];
        $isbn = $_POST["isbn"];
        //echo "check out";
    }
    
    else if ( 
        isset($_POST["borrower_name"]) && !empty($_POST["borrower_name"]) 
        && 
        isset($_POST["ssn"]) && !empty($_POST["ssn"])
        &&
        isset($_POST["phone"]) && !empty($_POST["phone"])
        &&
        isset($_POST["address"]) && !empty($_POST["address"])             
    ) {
        $borrower_name = $_POST["borrower_name"];
        $ssn = $_POST["ssn"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
//        echo "create borrower from php";
    }
    else if ( 
        
        isset($_POST["checkin_search_text"]) && !empty($_POST["checkin_search_text"]) 

    ) {
        $checkin_search_text = $_POST["checkin_search_text"];
//        echo "checkin book";
    }
    else if(
        isset($_POST["checkin_book_isbn"]) && !empty($_POST["checkin_book_isbn"])
        &&
        isset($_POST["checkin_book_card_id"]) && !empty($_POST["checkin_book_card_id"])
    ) {
        $checkin_book_isbn = $_POST["checkin_book_isbn"];
        $checkin_book_card_id = $_POST["checkin_book_card_id"];
    }
    else if (
        isset($_POST["show_fines"]) && !empty($_POST["show_fines"])
    ) {
        $search_for_all_fines = $_POST["show_fines"];
    }
    else if(
        isset($_POST["pay_fine_loan_id"]) && !empty($_POST["pay_fine_loan_id"])
    ) {
        $pay_fine_loan_id = $_POST["pay_fine_loan_id"];
    }
    else {
        echo json_response("Nothing to be searched");
    }
    
} else if($_SERVER["REQUEST_METHOD"] == "GET") {
    if(isset($_GET["search"]) && !empty($_GET["search"])) {
        $search_term = $_GET["search"];
    } else if ( 
            isset($_GET["borrower_id"]) && !empty($_GET["borrower_id"]) 
            && 
            isset($_GET["isbn"]) && !empty($_GET["isbn"])   
    ) {
        $borrower_id = $_GET["borrower_id"];
        $isbn = $_GET["isbn"];
    }
    else if ( 
        isset($_GET["borrower_name"]) && !empty($_GET["borrower_name"]) 
        && 
        isset($_GET["ssn"]) && !empty($_GET["ssn"])
        &&
        isset($_GET["phone"]) && !empty($_GET["phone"])
        &&
        isset($_GET["address"]) && !empty($_GET["address"])             
    ) {
        $borrower_name = $_GET["borrower_name"];
        $ssn = $_GET["ssn"];
        $phone = $_GET["phone"];
        $address = $_GET["address"];
//        echo "create borrower";
    }
    
    else if ( 
        isset($_GET["checkin_search_text"]) && !empty($_GET["checkin_search_text"])
    ) {
        $checkin_search_text = $_GET["checkin_search_text"];
//        echo "checkin book";
    }
    
    else if (
        isset($_GET["show_fines"]) && !empty($_GET["show_fines"])
    ) {
        $search_for_all_fines = $_GET["show_fines"];
    }
    
    else if(
        isset($_GET["pay_fine_loan_id"]) && !empty($_GET["pay_fine_loan_id"])
    ) {
        $pay_fine_loan_id = $_GET["pay_fine_loan_id"];
    }

    else {
        echo json_response("Nothing to be searched");
    }
}


// connect to DB
$user_name = "root";
$password = "root";
$db_name = "library";
$port = "8889";
$conn = connect_to_database($user_name, $password, $db_name, $port);

// proceed if search term is available
if (strlen($search_term) > 0) {
    if ($conn != null) {
        $sql_search = "
        SELECT
            ISBN as ISBN,
            TITLE as TITLE,
            NAME as NAME,
            BOOK_AVAILABILITY as BOOK_AVAILABILITY
        FROM
            searchbook
        WHERE
            (ISBN LIKE '%".$search_term."%' || TITLE LIKE '%".$search_term."%' || NAME LIKE '%".$search_term."%') 
            ;
        ";
        $results = execute_query($conn, $db_name, $sql_search);
        echo json_response($results);
    } else {
        echo json_response("Could not connect to database");
    }
} else if (strlen($borrower_id) > 0 && strlen($isbn) > 0) {
    if($conn) {
        //echo "check if book is available";
        $book_avail = check_book_availability($conn, $db_name, $isbn);
        if($book_avail == 1) {
            //echo " check if borrower has 3 books checked out";
            $no_of_books_checked_out = get_number_of_borrowed_books($conn, $db_name, $borrower_id);
            if ($no_of_books_checked_out < 3) {
                //echo "Continue checking out the book";
                check_out_book($conn, $db_name, $borrower_id, $isbn);
            } else {
                $temp_array = array();
                $temp_array["error"] = "borrower has checked out 3 books";
                echo json_response($temp_array);                
            }
        } else {
            $temp_array = array();
            $temp_array["error"] = "book is not available for check out";
            echo json_response($temp_array);
        }
    }
} else if (strlen($borrower_name) > 0 && strlen($ssn) > 0 && strlen($phone) > 0 && strlen($address) > 0) {
    
    $temp_array = array();
    if ($conn != null && mysqli_select_db($conn, $db_name)) {
        
        // get the last primary key
        $get_last_card_id_query = "select Card_ID as CARD_ID from borrower order by CARD_ID desc limit 1;";
        
//        $rows = mysqli_query($conn, $get_last_card_id_query);
        $results = mysqli_query($conn, $get_last_card_id_query);
        $rows = mysqli_fetch_row($results);
        //echo $rows[0];
        $card_id = (int)$rows[0]; 
        //echo $card_id . " fetched";
        $card_id += 1;
        $insert_query = "insert into borrower(`Card_ID`, `ssn`,`bname`,`phone`,`address`) values(".$card_id.", '".$ssn."','".$borrower_name."','".$phone."','".$address."');";
        
        if(mysqli_query($conn, $insert_query)) {
            $results = mysqli_query($conn, $get_last_card_id_query);
            $rows = mysqli_fetch_row($results);
            //echo $rows[0];
            $card_id = (int)$rows[0];
            $temp_array["borrower_id"] = $card_id;
        } else {
            $temp_array["error"] = "Could not create borrower because of " . mysqli_error($conn);
        }
    } else {
        $temp_array["error"] = "Could not connect to database";
    }
    echo json_response($temp_array);
} else if (strlen($checkin_search_text) > 0 )  {
    //  check in book
    if ($conn != null && mysqli_select_db($conn, $db_name)) {
        $search_book_loan_query = "select * from (select bl.isbn as BookID, bl.card_id as CardNumber, br.Bname as BorrowerName, bl.date_in as DATE_IN
        from book_loans bl, borrower br
        where bl.card_id=br.Card_ID and DATE_IN IS NULL) as 
        chk where chk.BookID like '%".$checkin_search_text."%' or chk.CardNumber like '%".$checkin_search_text."%' or chk.BorrowerName like '%".$checkin_search_text."%'
        ;";
        //echo $search_book_loan_query;
        $results = mysqli_query($conn, $search_book_loan_query);
        $search_results = array();
        while($row = mysqli_fetch_assoc($results)) {
            $temp_array = array();
            $temp_array["BOOK_ID"] = $row["BookID"];
            $temp_array["CARD_NUMBER"] = $row["CardNumber"];
            $temp_array["BORROWER_NAME"] = $row["BorrowerName"];
            array_push($search_results, $temp_array);
            //print_r($temp_array);
        }
//        if($search_results.length > 0) {
            echo json_response($search_results);
//        }
//        else {
//            echo json_response("No results");
//        }
    }
}
else if(strlen($checkin_book_isbn) > 0 && strlen($checkin_book_card_id) > 0) {
    //echo json_response("CHECK IN THIS " . $checkin_book_isbn . " & " . $checkin_book_card_id);
    if ($conn != null && mysqli_select_db($conn, $db_name)) {
        // update the searchbook table
        $update_searchbook_table_query = "update searchbook set BOOK_AVAILABILITY=1 where ISBN='".$checkin_book_isbn."';";
        if(mysqli_query($conn, $update_searchbook_table_query)) {
            // update the entry in the book loans, insert the check in date
            $update_book_loans_query = "update book_loans set date_in=now() where card_id=".$checkin_book_card_id." and isbn='".$checkin_book_isbn."';";
            
            if(mysqli_query($conn, $update_book_loans_query)){
                echo json_response("BOOK CHECK IN SUCCESSFUL for ISBN " . $checkin_book_isbn . " & card number " . $checkin_book_card_id);
            } else {
                echo json_response("IF 2 : BOOK CHECK IN FAILED for ISBN " . $checkin_book_isbn . " & card number " . $checkin_book_card_id . " - QUERY <br>".$update_book_loans_query);
            }
        } else {
            echo json_response("IF 1 : BOOK CHECK IN FAILED for ISBN " . $checkin_book_isbn . " & card number " . $checkin_book_card_id);
        }
    }
}
else if(strlen($search_for_all_fines) > 0) {
    if ($conn != null && mysqli_select_db($conn, $db_name)) {
        if ($search_for_all_fines == "ALL_FINE") {
            
            $search_all_fine_query = "
                SELECT BL.LOAN_ID
                ,BL.CARD_ID
                ,BL.DATE_IN
                ,BL.DATE_OUT
                ,(BL.DATE_IN-BL.DATE_OUT) NO_OF_DAYS
                ,sum((BL.DATE_IN-BL.DATE_OUT)*0.25) AS TOTAL_FINE_AMOUNT
                FROM BOOK_LOANS BL,FINES FN
                WHERE BL.DATE_IN>BL.DUE_DATE
                AND BL.LOAN_ID=FN.CARD_ID
                AND BL.DATE_IN IS NOT NULL
                AND FN.PAID=0
                GROUP BY BL.CARD_ID;";
            
            $search_all_fine_query1 = "SELECT BL.LOAN_ID
                ,BL.CARD_ID
                ,BL.DATE_IN
                ,BL.DATE_OUT               
               ,DATEDIFF(NOW(),bl.DATE_OUT) AS NO_OF_DAYS
               ,sum(DATEDIFF(NOW(),bl.DATE_OUT)*(0.25)) AS TOTAL_FINE_AMOUNT
                FROM BOOK_LOANS BL,FINES FN
                WHERE DATE_OUT<SYSDATE()
                AND BL.LOAN_ID=FN.CARD_ID
                AND FN.PAID=0
                AND BL.DATE_IN IS NULL
                GROUP BY BL.CARD_ID;";
            
            //echo json_response($search_all_fine_query);
            
           //if(mysqli_query($conn, $search_all_fine_query)){
                // retrieve all fields
                $results = mysqli_query($conn, $search_all_fine_query1);
                $pay_fine_search_results = array();
                while($row = mysqli_fetch_assoc($results)) {
                    $temp_array = array();
                    $temp_array["LOAN_ID"] = $row["LOAN_ID"];
                    $temp_array["CARD_ID"] = $row["CARD_ID"];
                    $temp_array["DATE_IN"] = $row["DATE_IN"];
                    $temp_array["DATE_OUT"] = $row["DATE_OUT"];
                    $temp_array["NO_OF_DAYS"] = $row["NO_OF_DAYS"];
                    $temp_array["TOTAL_FINE_AMOUNT"] = $row["TOTAL_FINE_AMOUNT"];
                    array_push($pay_fine_search_results, $temp_array);
                }
                //echo json_response($pay_fine_search_results);
            //echo("ANOTHER MAIN QUERY");
                
                $results1 = mysqli_query($conn, $search_all_fine_query);
                while($row = mysqli_fetch_assoc($results1)) {
                    $temp_array = array();
                    $temp_array["LOAN_ID"] = $row["LOAN_ID"];
                    $temp_array["CARD_ID"] = $row["CARD_ID"];
                    $temp_array["DATE_IN"] = $row["DATE_IN"];
                    $temp_array["DATE_OUT"] = $row["DATE_OUT"];
                    $temp_array["NO_OF_DAYS"] = $row["NO_OF_DAYS"];
                    $temp_array["TOTAL_FINE_AMOUNT"] = $row["TOTAL_FINE_AMOUNT"];
                    array_push($pay_fine_search_results, $temp_array);
                }
               
                echo json_response($pay_fine_search_results);
            
            
            $insert_query = "
                INSERT INTO FINES
                (SELECT BL.LOAN_ID
                ,sum(((BL.DATE_IN-BL.DATE_OUT)*0.25)) AS TOTAL_FINE_AMOUNT
                ,0
                FROM BOOK_LOANS BL,FINES FN
                WHERE BL.DATE_IN>BL.DUE_DATE
                AND BL.CARD_ID=FN.CARD_ID
                AND BL.DATE_IN IS NOT NULL
                GROUP BY BL.CARD_ID);";
            if(mysqli_query($conn, $insert_query)){
                
                $insert_query2 = "
                INSERT INTO FINES
                (SELECT BL.LOAN_ID
                ,sum(DATEDIFF(NOW(),bl.DATE_OUT)*(0.25)) AS TOTAL_FINE_AMOUNT
                ,0
                FROM BOOK_LOANS BL,FINES FN
                WHERE DATE_OUT<NOW()
                AND FN.CARD_ID=BL.CARD_ID
                AND BL.DATE_IN IS NULL
                GROUP BY BL.CARD_ID);
                
                ";
                if(mysqli_query($conn, $insert_query2)){
                    //echo json_response("fine amount paid successfully");
                } 
            } 
            
            
            
            
                //echo ("END OF QUERIES");
        /*    } else {
                echo json_response("Failed to execute search_all_fine_query");
            }*/
            
            
           
        }
    }
} else if (strlen($pay_fine_loan_id) > 0) {
    if ($conn != null && mysqli_select_db($conn, $db_name)) {
        $update_query = "
UPDATE FINES
SET PAID=1
WHERE LOAN_ID=".$pay_fine_loan_id.";";
        if(mysqli_query($conn, $update_query)) {
            echo json_response("FINE PAID Successfully");
        } else {
            echo json_response("UPDATE failed");
        }
    }
}

?>












